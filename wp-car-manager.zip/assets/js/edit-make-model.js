jQuery( function ( $ ) {
    Tipped.create( '.wpcm-has-tip',  { position: 'left' } );
    
    // Autofocus on 'Name' field
    $( '#tag-name' ).focus();
} );