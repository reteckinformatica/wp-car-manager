<input type="text" name="<?php echo $mb_prefix; ?>[<?php echo $field['key']; ?>]" id="<?php echo $field['key']; ?>" class="wpcm-text"
       value="<?php echo $value; ?>"/>
