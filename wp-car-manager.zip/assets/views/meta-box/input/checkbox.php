<input type="checkbox" name="<?php echo $mb_prefix; ?>[<?php echo $field['key']; ?>]" id="<?php echo $field['key']; ?>"
       value="1" <?php checked( '1', $value ); ?>/>
