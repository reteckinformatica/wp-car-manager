<fieldset class="wpcm-fieldset-disabled">
	<p><?php _e( 'You do not have permission to post or edit this listing.', 'wp-car-manager' ); ?></p>
</fieldset>
