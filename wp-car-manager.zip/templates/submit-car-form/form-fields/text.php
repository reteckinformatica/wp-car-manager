<input type="text" name="wpcm_submit_car[<?php echo $field['key']; ?>]" id="<?php echo $field['key']; ?>"
       class="wpcm-input-text"
       value="<?php echo $value; ?>"<?php echo( ( ! empty( $field['placeholder'] ) ) ? ' placeholder="' . $field['placeholder'] . '"' : '' ); ?>
/>