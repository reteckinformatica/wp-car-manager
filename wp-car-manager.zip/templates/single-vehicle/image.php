<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

?>
<!--Update by Reteck-->
<div class="wpcm-rtk-wrap-images wpcm-rom">
	<div class="carousel">
		<?php do_action( 'wpcm_vehicle_thumbnails', $vehicle ); ?>
	</div>	
</div>