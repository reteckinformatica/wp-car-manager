<div class="wpcm-notice">
	<h2><?php _e( 'Pending Review', 'wp-car-manager' ); ?></h2>
	<p><?php _e( 'Your submission is pending review, please check back later.', 'wp-car-manager' ); ?></p>
</div>