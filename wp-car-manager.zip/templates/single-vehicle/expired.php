<div class="wpcm-notice">
	<h2><?php _e( 'Listing Expired', 'wp-car-manager' ); ?></h2>
	<p><?php _e( 'This listing is expired, please go to your car dashboard for more information.', 'wp-car-manager' ); ?></p>
</div>