<ul class="wpcm-dashboard-profile-fields">
    <li id="wpcm-dashboard-profile-field-email">
        <label>
            <span class="wpcm-dashboard-profile-label">Email Address</span>
            <span class="wpcm-dashboard-profile-value" data-key="email"></span>
        </label>
    </li>
    <li id="wpcm-dashboard-profile-field-phone">
        <label>
            <span class="wpcm-dashboard-profile-label">Phone Number</span>
            <span class="wpcm-dashboard-profile-value" data-key="phone"></span>
        </label>
    </li>
</ul>