<ul class="wpcm-dashboard-profile-fields">
    <li id="wpcm-dashboard-profile-field-email">
        <label>
            <span class="wpcm-dashboard-profile-label">E-mail</span><!--Update by Reteck-->
            <span class="wpcm-dashboard-profile-value" data-key="email"></span>
        </label>
    </li>
    <li id="wpcm-dashboard-profile-field-phone">
        <label>
            <span class="wpcm-dashboard-profile-label">Telefone</span><!--Update by Reteck-->
            <span class="wpcm-dashboard-profile-value" data-key="phone"></span>
        </label>
    </li>
</ul>