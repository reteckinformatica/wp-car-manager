<h2>
    <?php _e( 'Meu perfil', 'wp-car-manager' ); ?>
    <a href="javascript:;" class="wpcm-button wpcm-button-dashboard-profile-edit"><?php _e( 'Edit', 'wp-car-manager' ); ?></a>
</h2>
