<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
?>
<a href="<?php echo esc_attr( $submit_url ); ?>" class="wpcm-button wpcm-button-dashboard-add-new"><?php _e( 'Add New', 'wp-car-manager' ); ?></a>
